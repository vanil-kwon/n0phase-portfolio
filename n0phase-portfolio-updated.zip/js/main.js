const menuButton = document.getElementById("menuToggle");
const mobileNav = document.getElementById("mobileNav");

function setMenu(open) {
  menuButton.setAttribute("aria-expanded", String(open));
  menuButton.setAttribute("aria-label", open ? "Закрыть меню" : "Открыть меню");
  mobileNav.classList.toggle("open", open);
  mobileNav.inert = !open;
}
menuButton?.addEventListener("click", () => {
  setMenu(menuButton.getAttribute("aria-expanded") !== "true");
});
mobileNav?.querySelectorAll("a").forEach(link => {
  link.addEventListener("click", () => setMenu(false));
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") setMenu(false);
});

const copyButton = document.getElementById("copyEmail");
const copyStatus = document.getElementById("copyStatus");
copyButton?.addEventListener("click", async () => {
  const email = "kwnvanil@gmail.com";
  try {
    await navigator.clipboard.writeText(email);
    copyStatus.textContent = "Email скопирован";
  } catch {
    copyStatus.textContent = "Не удалось скопировать. Используйте kwnvanil@gmail.com";
  }
});

const revealItems = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  revealItems.forEach(item => observer.observe(item));
} else {
  revealItems.forEach(item => item.classList.add("visible"));
}
